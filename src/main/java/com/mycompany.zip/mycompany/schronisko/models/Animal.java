/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.schronisko.models;

import java.io.Serializable;
import java.util.List;

//package com.mycompany.schronisko.hibernate;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Bartosz
 */
@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name = "zwierzaki")
public class Animal implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "gatunek")
    private String gatunek;

    @Column(name = "rasa")
    private String rasa;

    @Column(name = "plec")
    private String plec;

    @Column(name = "wiek")
    private int wiek;

    @Column(name = "data_przyjecia")
    private String data_przyjecia;

    @Column(name = "status")
    private String status;

    @OneToMany(mappedBy = "animal")
    private List<Vaccination> vaccinations;
    private List<Adopter> adopters;

    public Animal(String gatunek, String rasa, String plec, int wiek, String data_przyjecia, String status) {
        this.gatunek = gatunek;
        this.rasa = rasa;
        this.plec = plec;
        this.wiek = wiek;
        this.data_przyjecia = data_przyjecia;
        this.status = status;
    }

    public Animal(Long id, String gatunek, String rasa, String plec, int wiek, String data_przyjecia, String status) {
        this.id = id;
        this.gatunek = gatunek;
        this.rasa = rasa;
        this.plec = plec;
        this.wiek = wiek;
        this.data_przyjecia = data_przyjecia;
        this.status = status;
    }
}
