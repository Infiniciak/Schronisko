/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.schronisko.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import javax.persistence.*;

/**
 *
 * @author Bartosz
 */
@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name="adoptujacy")
public class Adopter implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idosoby;
    @Column(name="imie")
    private String imie;
    @Column(name="nazwisko")
    private String nazwisko;
    @Column(name="idzwierzaka")
    private int idzwierzaka;
    @Column(name="data_adopcji")
    private String data_adopcji;

    @ManyToOne(optional = false)
    @JoinColumn(name="idzwierzaka",insertable=false,updatable=false)
    private Animal animal;


    public Adopter(Long idosoby, String imie, String nazwisko, int idzwierzaka, String data_adopcji) {
        this.idosoby = idosoby;
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.idzwierzaka = idzwierzaka;
        this.data_adopcji = data_adopcji;
    }
    public Adopter(String imie, String nazwisko, int idzwierzaka, String data_adopcji) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.idzwierzaka = idzwierzaka;
        this.data_adopcji = data_adopcji;
    }
}


  


