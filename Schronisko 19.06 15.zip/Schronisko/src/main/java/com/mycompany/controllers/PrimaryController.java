package com.mycompany.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.mycompany.schronisko.App;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class PrimaryController implements Initializable {



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
